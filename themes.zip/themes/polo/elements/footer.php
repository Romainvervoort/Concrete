<script type="text/javascript" src="<?php echo $this->getThemePath();?>/assets/js/prefixfree.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->getThemePath();?>/assets/js/html5shiv.js"></script>
        <script type="text/javascript" src="<?php echo $this->getThemePath();?>/assets/js/html5shiv-printshiv.js"></script>
        <script type="text/javascript" src="<?php echo $this->getThemePath();?>/assets/js/jquery-1.8.3.min.js"></script>
    </body>
</html>