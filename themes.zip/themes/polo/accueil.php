<?php $this->inc('elements/header.php');?>

<div class="slider">
               
                       <?php
				 $a = new Area('col1');
					$a->display($c);
		?>
                </div>
              

            <div class="container_12">

             
                   <?php
				 $a = new Area('Contenu');
					$a->display($c);
					?>
                    </div>

             

          


                <div class="grid_4 solution">
                      <?php
				 $a = new Area('contact');
					$a->display($c);
		?>
                    </div>
                    


                <div class="grid_4 culture">
                       <?php
				 $a = new Area('Col5');
					$a->display($c);
		?>
                  

                </div>

            
                <div class="grid_4 social_con">
                 
                         <?php
				 $a = new Area('social');
					$a->display($c);
		?>
                    </div>

                    

                <div class="grid_4 contact">
                       <?php
				 $a = new Area('Col3');
					$a->display($c);
		?>

                </div>

                <div class="grid_4 news">
                     <?php
				 $a = new Area('Col4');
					$a->display($c);
		?>
            </div>
<?php $this->inc('elements/footer.php');?>