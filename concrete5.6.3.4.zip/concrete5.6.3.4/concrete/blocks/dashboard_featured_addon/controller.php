<?php
	defined('C5_EXECUTE') or die("Access Denied.");
	
	class DashboardFeaturedAddonBlockController extends Concrete5_Controller_Block_DashboardFeaturedAddon {

		
	}