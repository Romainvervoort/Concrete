<?php defined('C5_EXECUTE') or die("Access Denied.");
	
class TagsBlockController extends Concrete5_Controller_Block_Tags {


}