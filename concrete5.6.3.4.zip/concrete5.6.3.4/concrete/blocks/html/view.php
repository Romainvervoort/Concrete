<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<div id="HTMLBlock<?php echo intval($bID)?>" class="HTMLBlock">
<?php echo $content; ?>
</div>