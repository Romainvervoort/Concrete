<?php
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemSeoController extends Concrete5_Controller_Dashboard_System_Seo {}