<?php
defined('C5_EXECUTE') or die("Access Denied.");
class InstallController extends Concrete5_Controller_Install {


}

