<?php
defined('C5_EXECUTE') or die("Access Denied."); 

Loader::model('user_list');  

class MembersController extends Concrete5_Controller_Members {

}
