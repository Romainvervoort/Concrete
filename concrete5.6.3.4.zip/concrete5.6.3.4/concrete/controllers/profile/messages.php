<?php
defined('C5_EXECUTE') or die("Access Denied.");

class ProfileMessagesController extends Concrete5_Controller_Profile_Messages {


}